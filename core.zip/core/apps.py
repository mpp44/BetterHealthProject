import os
from django.apps import AppConfig
from django.core.exceptions import ObjectDoesNotExist

class CoreConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'core'

    def ready(self):
        import core.signals


class YourAppConfig(AppConfig):
    name = 'your_app'

    def ready(self):
        from .models import StaffUser
        from django.conf import settings
        import dotenv
        dotenv.load_dotenv()

        username = os.getenv("ADMIN_USERNAME")
        password = os.getenv("ADMIN_PASSWORD")

        if username and password:
            try:
                StaffUser.objects.get(username=username)
            except StaffUser.DoesNotExist:
                user = StaffUser(username=username, role='superadmin')
                user.set_password(password)
                user.save()